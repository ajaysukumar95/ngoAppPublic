import firebase from 'firebase'
const firebaseConfig = {
    apiKey: "AIzaSyBgs15chyMPxrC1FY-JSilnlIPS5CfiOmk",
    authDomain: "invoicegenerator-efca1.firebaseapp.com",
    databaseURL: "https://invoicegenerator-efca1.firebaseio.com",
    projectId: "invoicegenerator-efca1",
    storageBucket: "invoicegenerator-efca1.appspot.com",
    messagingSenderId: "84227204350",
    appId: "1:84227204350:web:04089bd984e29fbd07f1af",
    measurementId: "G-KXKBGMGJEK"
  };

firebase.initializeApp(firebaseConfig); //storing the config to firebase app

